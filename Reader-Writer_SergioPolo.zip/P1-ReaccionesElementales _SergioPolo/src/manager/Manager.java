package manager;

import dao.Escribir;
import dao.Leer;
import staticAndLibraries.ReaccionesElementales;

import java.io.File;
import java.util.*;
import java.lang.*;

public class Manager {
    private Scanner scanner;

    public Manager(){
        this.scanner = new Scanner(System.in);
        init();
    }

    private void init(){
        System.out.println("Bienvenido al generador de reacciones.");
        ArrayList<String> rutasFicheros = new ArrayList<String>(Arrays.asList(pedirRutaFicheros("personajes"), pedirRutaFicheros("elementos")));
        Escribir escritor = new Escribir("result.txt");
        //1a Parte:
        escribirTotalPersonajes(escritor, rutasFicheros);
        escribirTotalElementos(escritor, rutasFicheros);
        escribirNumeroPersonajesXElementos(escritor, rutasFicheros);
        //2a Parte:
        Leer lector = new Leer(rutasFicheros.get(1));
        logicaReaccionesRecursiva(lector, escritor,1, rutasFicheros.get(0), (char) lector.leerCaracter(), (char) lector.leerCaracter());

        //close
        escritor.cerrarWriter();
        //Readers ya se cierran solos
    }
    //in
    private String pedirRutaFicheros(String palabraClave){
        System.out.print("Ubicacion correcta de los datos de los " + palabraClave + ": ");
        String ubicacionPersonajes = scanner.nextLine();
        if(new File(ubicacionPersonajes).exists()) return ubicacionPersonajes;
        return pedirRutaFicheros(palabraClave);
    }
    private void escribirTotalPersonajes(Escribir escritor, ArrayList<String> rutasFicheros){
        //System.out.println("Total de personajes: " + contarDistinctArray(0, rutasFicheros.get(0)).length);
        escritor.escribir("Total de personajes: " + contarDistinctArray(0, rutasFicheros.get(0)).length);
        escritor.insertarLinea();
    }
    private void escribirTotalElementos(Escribir escritor, ArrayList<String> rutasFicheros){
        //System.out.println("Total de personajes: " + contarDistinctArray(0, rutasFicheros.get(0)).length);
        //System.out.println("Total de elementos utilizados: " + contarDistinctArray(1, rutasFicheros.get(0)).length);
        escritor.escribir("Total de elementos utilizados: " + contarDistinctArray(1, rutasFicheros.get(0)).length);
        escritor.insertarLinea();
    }
    private void escribirNumeroPersonajesXElementos(Escribir escritor, ArrayList<String> rutasFicheros){
        escritor.escribir("Total de personajes por elemento: ");
        escritor.insertarLinea();
        escribirArray(escritor, combinatoriaPersonajesElementos(contarDistinctArray(1, rutasFicheros.get(0)), createArray(rutasFicheros.get(0))), " : ", 0, 0);
    }
    private String[] contarDistinctArray(int position, String rutaFichero){
        Set<String> setDistinct = new LinkedHashSet<>(Arrays.asList(createArrayFromSplitElements(position, rutaFichero)));

        return setDistinct.toArray(new String[setDistinct.size()]);
    }
        //in
    private String[] createArrayFromSplitElements(int posicion, String rutaFichero){
        Leer lecturaFichero = new Leer(rutaFichero);
        ArrayList<String> array = new ArrayList<String>();
       for(String linea = lecturaFichero.leerLinea(); linea != null; linea = lecturaFichero.leerLinea()) array.add(linea.split(" ")[posicion]);
       lecturaFichero.cerrarReader();
       return array.toArray(new String[array.size()]);
    }
        //out

    //funcion que automaticamente te crea un objeto de la combinatoria calculada
    /*Importante: A la hora de generalizar con Object. No utilizar Objects.
                Objects             |        Object
                java.util           |        java.lang
                Class Objects       |        Class Object

            java.util.Objects       |        java.lang.Object

      Objects es una clase de metodos static para operar el objetos (Object). De la cual puede lanza nullPointerException.
     */
    private Object[][] combinatoriaPersonajesElementos(String[] arrayBase, String[] arrayTrabajo){
        Object[][] arrayDef = new Object[arrayBase.length][2];
        for(int i = 0; i < arrayBase.length; i++){
            arrayDef[i][0] = arrayBase[i];
            arrayDef[i][1] = 0;
            for(int j = 0; j < arrayTrabajo.length; j++){
                if(arrayTrabajo[j].split(" ")[1].equals(arrayBase[i])){
                    /*
                    Aqui se ha de tener cuidado. Como la matriz es de objetos de la clase Object.
                    Cuando se define las posiciones iniciales mas arriba: una como un String y la otra como Integer.
                    Si queremos modificar el valor del Integer, este se leera primero como un Object y no podremos hacer una modificacion numerica de un Object
                    Para esto, entonces deberemos parsear el objecto a su respectivo Integer (aunque ya lo sea) para que podamos aplicar operaciones y modificar el numero.
                    el intValue sobra pero lo he puesto para enfatizar que el casteo es necesario para obtener el valor del Objeto como un numero (Integer).
                     */

                    arrayDef[i][1] = ((Integer) arrayDef[i][1]).intValue() + 1;

                    /* Da error en este codigo comentado: expected variable. No tengo explicacion, de momento.
                    arrayDef[i][1] != null?arrayDef[i][1] = (Integer) arrayDef[i][1] + 1:arrayDef[i][1] = 1;
                    if(arrayDef[i][1] != null) arrayDef[i][1] = (Integer) arrayDef[i][1] + 1;
                    else arrayDef[i][1] = 1;

                    arrayDef[i][1] = arrayDef[i][1] != null? (Integer) arrayDef[i][1] + 1: 1;
                    */


                }
            }
        }
        return arrayDef;
    }
        //in
    private String[] createArray(String rutaFichero){
        Leer lecturaFichero = new Leer(rutaFichero);
        ArrayList<String> array = new ArrayList<>();
        for(String linea = lecturaFichero.leerLinea(); linea != null;  array.add(linea), linea = lecturaFichero.leerLinea());
        lecturaFichero.cerrarReader();
        return array.toArray(new String[array.size()]);
    }
        //out
    public void escribirArray(Escribir escritor, Object[][] array, String separador, int n, int k){
        if(n <= array.length - 1){
            if(k <= array[n].length - 1){
                if(k % 2 != 0) escritor.escribir(separador);
                escritor.escribir(array[n][k].toString());
                escribirArray(escritor, array, separador, n, ++k);
            }else {
                escritor.insertarLinea();
                escribirArray(escritor, array, separador, ++n, k = 0);
            }
            //No poner esto aqui: printArray(array, n, ++k); Ya que la recursividad intenta cerrar sus funciones abiertas
        }
    }

    /*El objetivo para calcular reacciones elementales en esta practica es:
    Calcula cuales reacciones se producen juntas (importante). No cuantas pueden haber posibles sino cuantas hay posibles pero que esten juntas.
    Para calcular cuales pueden haber posibles a partir de unos caracteres no deberiamos eliminar (obviar) el primer caracter a comprobar por reaccion
     */
    /*
    En este proyecto, no se ha conseguido hallar un algoritmo matematico capaz de determinar el valor de un caracter = posicion en matriz
    por la arbitrariedad de una secuencia de caracteres. Al intentar pensarlo, uno se da cuenta de que para calcular ese valor
    uno ha de saber una relacion (indirecta o directa) exacta de la secuencia de caracteres. El unico problema, es que esa secuencia
    podria ser combinatoriamente infinita ademas de arbitraria.
    Para que se entienda mejor:
    Inicialmente para resolver el problema se habian pensado 2 distintas maneras de resolver el problema:
    1 - Conociendo unicamente la longitud de caracteres que hay en el fichero. En otras palabras, acabar consiguiendo cuantos distintos.
    El objetivo es que a partir de su valor decimal, hexadecimal... y el la longitud de caracteres distintos conseguir
    la posicion exacta a partir de operaciones matematicas.
    La unica manera de intentar conseguir hacer esto posible es utilizando recursividad o un bucle.
    La funcion recursiva o bucle tendra como parametro o variable global, respectivamente, la cantidad de caracteres que ha encontrado.
    Por lo tanto: La funcion o bucle empieza: a la que -"encuentra un caracter nuevo" = cuando a partir de las operaciones matematicas
    el valor de ese caracter supere al parametro - 1- entonces se repite sumando 1 al parametro global (ya que la funcion es recursiva)
    asi indicando que ahora los caracteres leidos y registrados ha aumentado. Asi haciendo que la vez que no registre nuevos caracteres
    sera el resultado final que se puede almacenar en un arraylist (que es dinamica a lo largo de la funcion recursiva o bucle).
    Dicho esto, todavia no se ha encontrado el procedimiento matematico para saber la posicon debido a la aleatoriedad
    del siguiente caracter que se puede registrar donde su valor decimal y por lo tanto posicion puede ser menor que el mayor o mayor que el mayor.
    Creo que se deberia pues conocer una relacion indirecta, al menos, de los caracteres que se deben registrar.
    Si no se hace, tod0 es aleatorio.

    2 - Conociendo una relacion (directa o indirecta) como "que" caracteres que habian en ese fichero para luego ordenarlos
    alfabeticamente o lo mismo: deci,hexa,oct - decimalmente (por tamaño) y entonces atribuir un valor a cada caracter que es igual a la posicion
    de la matriz ordenada.
    Una vez hecho este paso, la combinatoria de dos reacciones por esa matriz es R = (n - 1)Sigma(i=1) (i)
    haciendola una matriz triangular decreciente. (Explicado en ReaccionesElementales.java)
    Siempre teniendo en cuenta que primero hemos de organizar los dos caracteres que pueden formar una posible reaccion
    alfabeticamente tambien (de menor a mayor) --> esto habilita a que se genere la matriz triangular decreciente.
    Se utiliza esta, la cual no es tan emocionante.
     */

    //En esta parte del proyecto se ha dedicado a el principio SOLID y optimizacion de codigo (e.g: indexOf)
    private void logicaReaccionesRecursiva(Leer lector, Escribir escritor, int posicionSplitCaracteres, String rutaFichero, char primerCaracter, char segundoCaracter){
        String result = retornarReaccion(calcularPosicionReaccion(ReaccionesElementales.arrayCaracteres, ordenarCaracters(new char[]{primerCaracter, segundoCaracter})));
        try{
            if(!result.equals("fin")){
                escribirReaccion(escritor, result);
                logicaReaccionesRecursiva(lector, escritor, posicionSplitCaracteres, rutaFichero, (char) lector.leerCaracter(), (char) lector.leerCaracter());
            }
        }catch(NullPointerException npe){
            logicaReaccionesRecursiva(lector, escritor, posicionSplitCaracteres, rutaFichero, segundoCaracter, (char) lector.leerCaracter());
        }


        //result != null ? escribirReaccion(escritor, result) : logicaReaccionesRecursiva(lector, escritor, posicionSplitCaracteres, rutaFichero, segundoCaracter, (char) lector.leerCaracter());
    }

    private char[] ordenarCaracters(char[] arrayCaracteresDesordenados){
        if((int) arrayCaracteresDesordenados[0] == 65535 || (int) arrayCaracteresDesordenados[1] == 65535) return null;
        Arrays.sort(arrayCaracteresDesordenados);
        char[] arrayOrdenadaMayorMenor = new char[arrayCaracteresDesordenados.length];
        for(int i = arrayCaracteresDesordenados.length - 1, j = 0; i >= 0; i--, j++) arrayOrdenadaMayorMenor[j] = arrayCaracteresDesordenados[i];
        return arrayOrdenadaMayorMenor;
    }
    /*
    Notese que aqui se pueden utilizar varias formas para optimizar el codigo:
    1 - Pasar directamente la ArrayList<Character> para utlizar un indexOf
    2 - Pasar por ReaccionesElementales.java o procesar en Manager.java una array de char que tienen los personajes y entonces¨:
        convertirArrayStringChar    - Juntamos toda la array de String a un String juntarArrayString.
        convertirArrayStringChar    - pasamos ese String a una array de chars
        calcularPosicionReaccion    - esa array de chars la pasamos a una lista de chars
        calcularPosicionReaccion    - esa lista nos habilita a utilizar indexOf para buscar un caracter en la array y de la posicion
        calcularPosicionReaccion    - esa posicion es el valor del caracter y se busca en la matriz static de reacciones elementales
     */
    private char[] convertirArrayStringChar(String[] arrayString){
        String juntarArrayString = String.join("", arrayString);
        return juntarArrayString.toCharArray();
    }
    private int[] calcularPosicionReaccion(ArrayList<Character> arrayBase, char[] arrayCaracteresOrdenados){
        if(arrayCaracteresOrdenados == null) return null;

        //List<char[]> arrayBaseOrdenadaList = Arrays.asList(arrayCharBaseOrdenada);

        return new int[]{arrayBase.indexOf(arrayCaracteresOrdenados[0]), arrayBase.indexOf(arrayCaracteresOrdenados[1])};
    }
    private String retornarReaccion(int[] posiciones){
        if(posiciones == null) return "fin";
        return ReaccionesElementales.reaccionesElementales[posiciones[0]][posiciones[1]];
    }
    private void escribirReaccion(Escribir escritor, String texto){
        escritor.escribir(texto);
        escritor.insertarLinea();
    }
    //out

}
