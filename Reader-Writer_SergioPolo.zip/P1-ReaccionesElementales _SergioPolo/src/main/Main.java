package main;

import manager.Manager;

public class Main {
    public static void main(String[] args) {
        new Manager();
    }
}
