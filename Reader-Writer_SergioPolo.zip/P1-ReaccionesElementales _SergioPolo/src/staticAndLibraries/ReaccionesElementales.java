package staticAndLibraries;

import java.util.ArrayList;
import java.util.Arrays;

/*
Este es el unico fichero que se pide al cliente para que rellene y el programa funcionara automatizado.
Tambien ha de pasar los ficheros de personajes.txt y elementos.txt
 */
public class ReaccionesElementales {
    /*
    Demostracion del proceso escogido:

    Como se trata de combinatoria de las cuales nos fijamos en la posicion de los caracteres (u Objetos podrian ser)
    y ademas tanto AF = FA (es conmutativa: no importa el orden que el resultado es el mismo).
    Entonces podemos aplicar una tecnica de la cual reduce el tamaño y tiempo necesario para procesar
    la reaccion:
        Cuando se piensa en combinatoria en programacion podemos pensar en una matriz cuadrada donde cada posicion
        es una reaccion. Como AF = FA, es decir es conmutativa, a lo largo de la matriz cuadrada se repetiran reacciones.
        Para reducir el tamaño de esta matriz se puede utilizar una premisa para tod0 procesamiento de reacciones. Ordenar
        el objeto por tamaño. Tanto de menor a mayor o de mayor a menor asi pues convirtiendo esa matriz cuadrada
        en una matriz triangular.

     Bien, cuando trabajamos tanto con una matriz cuadrada o triangular estamos trabajando con matrices de 2 dimensiones.
     Como consecuencia encontraremos que hay unas matrices dentro de otra.

     Esto pues tiene una relacion con la matriz resultante y el procedimiento a escoger:
     Intuyo que solo existen 2 procedimientos:
     1 - Organizar Reacciones por orden alfabetico (de menor a mayor tamaño: A = 0, F = 1, H = 2) y generar una matriz triangular donde
     cada posicion sea una combinacion ordenada de Mayor a menor tamaño:
     AA
     FA FF
     HA HF HH
     2 - Organizar Reacciones de mayor a menor tamaño: V = 0, T = 1, R = 2 y generar una matriz triangular donde cada posicion sea una
     combinacion ordenada de menor a mayor tamaño
    :
    VV
    TV TT
    RV RT RR
     */
    /*
    Esta matriz de caracteres son los caracteres que has decidido que formen reacciones ordenados alfabeticamente
     */
    public static ArrayList<Character> arrayCaracteres = new ArrayList<Character>(Arrays.asList('A', 'F', 'H', 'N', 'R', 'T', 'V'));

    /*
    Se escoge el primer procedimiento
     */
    public static String[][] reaccionesElementales = {
            {null},
            {"Evaporacion", null},
            {"Congelar", "Derretido", null},
            {null, "Quemadura", null, null},
            {"Electro-carga", "Sobrecarga", "Superconductor", null, null},
            {"Cristalizar", "Cristalizar", "Cristalizar", null, "Cristalizar",  null},
            {"Torbellino", "Torbellino", "Torbellino", null, "Torbellino", null, null}
    };


}
