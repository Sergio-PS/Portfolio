Practica no terminada.
Objetivo: A partir de x puntos. Determina que figura es y que área tiene.

Sin embargo, hay casuísticas que aun no se han corregido y que podrían llevar al programa a resultados erróneos como por ejemplo cuando el punto x3 se define fuera del rango entre en vector v2 = x2 - v1. Es decir, que si se define fuera dentro el perímetro del vector v2 (fuera) la formula utilizada para calcular la altura del triangulo y posteriormente el área. Ya que se ha optado en utilizar una formula donde se calcule la distancia mínima entre una recta definida con formula continua y un punto.

Sin embargo, esto tiene fácil solución ya que si se impone una simple condición luego se revierte el orden de los puntos y entonces la función secuencia del calculo del área es correcta ya que la altura es posible de calcular sin error.

Creo que como la figura se define con un input que tiene un orden. La manera más optima en el caso de triangulos escalenos es cambiar el orden del triangulo para calcular correctamente el area. Tambien se pudiera haber calculado el area con otra formula utilizando el perimetro del triangulo.

Al proyecto todavia le queda edicion.