package modelo;

public class Recta{
    protected int x1;
    protected int y1;
    protected int x2;
    protected int y2;
    protected int i;
    protected int j;
    protected int A;
    protected int B;
    protected int C;

    /*Ecuacion continua de la recta: Ax + By + C = 0
    Donde:
        A = v2 = j
        B = - v1 = -i
        C = -v2 * x1 + v1 * y1 = -j * x1 + i * y1
     */
    public Recta(Punto puntoX1, Punto puntoX2){
        this.x1 = puntoX1.getX();
        this.y1 = puntoX1.getY();
        this.x2 = puntoX2.getX();
        this.y2 = puntoX2.getY();
        this.i = puntoX2.getX() - puntoX1.getX();
        this.j = puntoX2.getY() - puntoX1.getY();
        this.A = this.j;
        this.B = -this.i;
        this.C = (-this.j * this.x1 + this.i * this.y1);
    }

    public int getA() {
        return this.A;
    }
    public int getB() {
        return this.B;
    }
    public int getC() {
        return this.C;
    }
}
