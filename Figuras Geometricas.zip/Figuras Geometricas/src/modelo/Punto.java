package modelo;

public class Punto{
    protected int x;
    protected int y;

    public Punto(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int getX(){
        return this.x;
    }
    public int getY(){
        return this.y;
    }
}
