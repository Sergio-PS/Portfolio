package modelo.figuras.figurasGeometricas;

import modelo.Punto;
import modelo.Vector;
import modelo.figuras.Figura;

import java.lang.Math;

public class Circumferencia extends Figura {
    private Punto p1;
    private Punto p2;

    public Circumferencia(Punto p1, Punto p2){
        super("Circumferencia");
        this.p1 = p1;
        this.p2 = p2;
    }

    @Override
    protected double calculateArea(){
        /*int vectorX = Math.abs(this.p2.getX() - this.p1.getX());
        int vectorY = Math.abs(this.p2.getY() - this.p1.getY());
        double hipotenusa = Math.sqrt(Math.pow(vectorX, 2) + Math.pow(vectorY, 2));

        return Math.PI * Math.pow((hipotenusa / 2), 2);
         */
        return Math.PI * Math.pow((new Vector(this.p1, this.p2).getModulo() / 2), 2);
    }

}
