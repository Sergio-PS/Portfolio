package modelo.figuras.figurasGeometricas;

import modelo.Punto;
import modelo.Vector;
import modelo.figuras.Figura;

import java.lang.Math;

public class Cuadrado extends Figura {
    private Punto p1;
    private Punto p2;
    private Punto p3;
    private Punto p4;

    public Cuadrado(Punto p1, Punto p2, Punto p3, Punto p4){
        super("Cuadrado");
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.p4 = p4;
        super.area = this.calculateArea();
    }

    @Override
    protected double calculateArea(){
        return Math.pow(new Vector(this.p1, this.p2).getModulo(), 2);
    }
}
