package modelo.figuras.figurasGeometricas;

import modelo.Punto;
import modelo.Recta;
import modelo.Vector;
import modelo.figuras.Figura;

import java.lang.Math;

public class Triangulo extends Figura {
    private Punto p1;
    private Punto p2;
    private Punto p3;

    public Triangulo(Punto p1, Punto p2, Punto p3){
        super("Triangulo");
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }

    @Override
    public double calculateArea(){
        /*
        int vector1 = Math.abs(this.p2.getX() - this.p1.getX());
        int vector2;
        if(vector1 != 0){
            vector2 = Math.abs(this.p3.getY() - this.p2.getY());
        }else{
            vector1 = Math.abs(this.p2.getY() - this.p1.getY());
            vector2 = Math.abs(this.p3.getX() - this.p2.getX());
        }*/
        Vector recta = new Vector(this.p1, this.p2);
        double altura = (Math.abs(recta.getA()) * this.p3.getX() + recta.getB() * this.p3.getY() + recta.getC()) / Math.sqrt(Math.pow(recta.getA() ,2) + Math.pow(recta.getB(), 2));
        return (recta.getModulo() * altura) / 2;

    }
}
