package modelo.figuras.figurasGeometricas;

import modelo.Punto;
import modelo.figuras.Figura;
import modelo.Vector;

import java.lang.Math;

public class Rectangulo extends Figura {
    private Punto p1;
    private Punto p2;
    private Punto p3;
    private Punto p4;

    public Rectangulo(Punto p1, Punto p2, Punto p3, Punto p4){
        super("Rectangulo");
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.p4 = p4;
    }

    @Override
    protected double calculateArea(){
        /*int vector1 = Math.abs(this.p2.getX() - this.p1.getX());
        if(vector1 == 0) vector1 = Math.abs(this.p2.getY() - this.p1.getY());
        int vector2 = Math.abs(this.p3.getY() - this.p2.getY());
        if(vector2 == 0) vector2 = Math.abs(this.p3.getX() - this.p2.getX());
        */
        return new Vector(this.p1, this.p2).getModulo() * new Vector(this.p2, this.p3).getModulo();
    }
}
