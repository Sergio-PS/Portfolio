package modelo.figuras;

public class Figura {
    protected String nombre;
    protected double area;

    protected Figura(String nombre){
        this.nombre = nombre;
        //this.area = calculateArea();
    }

    protected double calculateArea(){
        return 1;
    }

    public String getNombre() {
        return this.nombre;
    }
    public double getArea(){
        return this.area;
    }
}
