package modelo;

import java.lang.Math;

public class Vector extends Recta{
    protected double modulo;

    public Vector(Punto puntoX1, Punto puntoX2){
        super(puntoX1, puntoX2);

        this.modulo = Math.sqrt(Math.pow(this.i, 2) + Math.pow(this.j, 2));
    }

    public double getModulo(){
        return this.modulo;
    }


}
