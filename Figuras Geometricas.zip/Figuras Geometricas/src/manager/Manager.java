package manager;

import modelo.Punto;
import modelo.figuras.figurasGeometricas.Circumferencia;
import modelo.figuras.figurasGeometricas.Cuadrado;
import modelo.figuras.figurasGeometricas.Rectangulo;
import modelo.figuras.figurasGeometricas.Triangulo;

import java.lang.Math;
import java.util.Scanner;

public class Manager {
    public Manager(){
        menu();
    }

    private void menu(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Este programa determina la figura geometrica y su area a partir de puntos dados\n-------------------" +
                "\nPor el momento: existen 4 figuras geometricas:\n- Circumferencia\n- Cuadrado\n- Triangulo\n- Rectangulo" +
                "\n-------------------\nSintaxis: x1 y1 x2 y2 ... Separado cada valor por un espacio\nDonde x e y pueden tener cualquier valor natural y los puntos se definen en alguno de los dos sentidos de las agujas del reloj" +
                "\nIntroduzca figura: ");
        String input;
        do{
            input = scanner.nextLine();
            String[] arrayStrings = input.split(" ");
            if(arrayStrings.length % 2 == 0 && arrayStrings.length <= 8 && arrayStrings.length >= 4){
                Punto[] arrayPuntos = new Punto[arrayStrings.length / 2];
                for(int i = 0, position = 0; i < arrayStrings.length; i += 2, position++) arrayPuntos[position] = new Punto(Integer.parseInt(arrayStrings[i]), Integer.parseInt(arrayStrings[i + 1]));
                if(arrayPuntos.length == 2) System.out.println("Figura geometrica: " + new Circumferencia(arrayPuntos[0], arrayPuntos[1]).getNombre() + "\nArea: " + new Circumferencia(arrayPuntos[0], arrayPuntos[1]).getArea() + " u^2");
                else if(arrayPuntos.length == 3) System.out.println("Figura geometrica: " + new Triangulo(arrayPuntos[0], arrayPuntos[1], arrayPuntos[2]).getNombre() + "\nArea: " + new Triangulo(arrayPuntos[0], arrayPuntos[1], arrayPuntos[2]).getArea() + " u^2");
                else{
                    if(Math.abs(arrayPuntos[2].getX() - arrayPuntos[0].getX()) == Math.abs(arrayPuntos[2].getY() - arrayPuntos[0].getY())){
                        System.out.println("Figura geometrica: " + new Cuadrado(arrayPuntos[0], arrayPuntos[1], arrayPuntos[2], arrayPuntos[3]).getNombre()
                                + "\nArea: " + new Cuadrado(arrayPuntos[0], arrayPuntos[1], arrayPuntos[2], arrayPuntos[3]).getArea() + " u^2");
                    }
                    else System.out.println("Figura geometrica: " + new Rectangulo(arrayPuntos[0], arrayPuntos[1], arrayPuntos[2], arrayPuntos[3]).getNombre()
                            + "\nArea: " + new Rectangulo(arrayPuntos[0], arrayPuntos[1], arrayPuntos[2], arrayPuntos[3]).getArea() + " u^2");
                }
            }else System.out.println("Figura geometrica no comprendida");
        }while(input.length() < 1);
    }
}
